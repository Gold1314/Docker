CREATE TABLE person (
    personId integer primary key auto_increment,
    firstName varchar(255),
    lastName varchar(255),
    company varchar(255)
);

insert into person (firstName, lastName, company) values 
   ('steve', 'jobs', 'apple'),
   ('bill', 'gates', 'ms'),
   ('sundar', 'pichchai', 'google'),
   ('larry', 'ellison', 'oracle');