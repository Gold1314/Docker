print("welcome to python application")
